<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Calculadora PHP</title>
    <style>
        form {
            text-align: center;
        }
        body{
            font-size: 20px;
            text-align: center;
            background-image: url(".idea/inspectionProfiles/1.jpg");
        }
        h1{
            1.5em;
        }
    </style>
</head>
<body>
    <h1> Resultado do Calculo</h1>
        <?php
        $valor1 = $_POST['valor1'];
        $valor2 = $_POST['valor2'];
        $tipo = $_POST['tipo'];


            switch($tipo)
            {
                case 'Soma': $result = $valor1 + $valor2; break;
                case 'Subtrair': $result = $valor1 - $valor2; break;
                case 'Multiplicar': $result = $valor1 * $valor2; break;
                case 'Dividir': $result = $valor1 / $valor2; break;
            }

            echo $result;
        ?>
</body>
</html>

//Não fiz com 4 botões, pois preferi fazer em modo que selecione a operação que deseja(Comando de seleção) achei mais organizado.
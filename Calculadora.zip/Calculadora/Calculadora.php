<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Calculadora PHP</title>
    <style>
        form {
            text-align: center;
        }
        body{
            font-size: 20px;
            text-align: center;
            background-image: url(".idea/inspectionProfiles/1.jpg");
        }
        h1{
            1.5em;
        }
    </style>
</head>
<body>
    <h1> C A L C U L A D O R A </h1>
    <br><form method="post" action="calcular.php"><br><br><br><br><br><br><br>
        Valor 1:
        <input type="number" name="valor1" size="5"/>
        <select name="tipo">
            <option selected="selected">Soma</option>
            <option>Subtrair</option>
            <option>Multiplicar</option>
            <option>Dividir</option>
        </select>
        Valor 2:
        <input type="number" name="valor2" size="5"/>
        <input type="submit" name="Calcular" value="calcular"/>
    </form>
</body>
</html>